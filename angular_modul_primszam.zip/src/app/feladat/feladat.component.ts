import { Component } from '@angular/core';

@Component({
  selector: 'app-feladat',
  templateUrl: './feladat.component.html',
  styleUrls: ['./feladat.component.css']
})
export class FeladatComponent {
  vizsgalandoSzam: number = 0;
  megoldas: string[] = [];

  EredmenyMentes(): void {

    let osztokSzama: number = 0;
    for (let i: number = 1; i <= this.vizsgalandoSzam; i++) {
      if (this.vizsgalandoSzam % i == 0) {
        osztokSzama++
      }
    }
    if (osztokSzama == 2) {
      this.megoldas.push(`A(z) ${this.vizsgalandoSzam} prím`);
    }
    else {
      this.megoldas.push(`A(z) ${this.vizsgalandoSzam} NEM prím`);
    }
  }


}
