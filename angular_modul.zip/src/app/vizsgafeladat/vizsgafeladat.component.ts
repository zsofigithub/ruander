import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vizsgafeladat',
  templateUrl: './vizsgafeladat.component.html',
  styleUrls: ['./vizsgafeladat.component.css']
})
export class VizsgafeladatComponent {
  constructor(){}
  ngOnInit():void{}
  

  suly:number=0;
  magassag:number=0;
  eredmeny:string[]=[];
  EredmenyMentes():void{
    this.eredmeny.push(`Az ${this.suly}kg testsúlyú és ${this.magassag}m magasságú ember testtömeg indexe: ${this.suly/(this.magassag*this.magassag)}`)
  }

}
